create function getscore(points bigint, typ "ParametrizedValueTypes", pid integer) returns double precision
  immutable
  language plpgsql
as
$$
DECLARE
  result FLOAT;
BEGIN
  SELECT INTO result points::FLOAT * "Representation"::FLOAT / "Max"::FLOAT
  FROM "Contest"
  JOIN "Parameter" ON "Parameter"."ParameterSetId" = "Contest"."ParameterSetId"
  WHERE "Contest"."Id" = pid AND "Parameter"."Type" = typ;
  IF result IS NULL THEN
    RETURN 0;
  ELSE
    RETURN result;
  END IF;
END;
$$;

alter function getscore(bigint, "ParametrizedValueTypes", integer) owner to postgres;

