create view "AllTimesScore" as
SELECT sum("Score"."Score") AS "Score",
       "Score"."UserId"
FROM "Score"
GROUP BY "Score"."UserId";

alter table "AllTimesScore"
  owner to postgres;

