create function getactiveparameterid(typ "ParametrizedValueTypes") returns integer
  immutable
  language plpgsql
as
$$
DECLARE result INTEGER;
  BEGIN
    RAISE NOTICE '%', typ;
    SELECT INTO result "Parameter"."Id" FROM "ActiveContest"
        JOIN "Contest" ON "Contest"."Id" = "ActiveContest"."ContestId"
        JOIN "Parameter" ON "Parameter"."ParameterSetId" = "Contest"."ParameterSetId"
        WHERE "Parameter"."Type" = typ;
    RETURN result;
  END;
$$;

alter function getactiveparameterid("ParametrizedValueTypes") owner to postgres;

