create view "CurrentContestScore" as
SELECT sum("Score"."Score") AS "Score",
       "Score"."UserId"
FROM ("Score"
       JOIN "ActiveContest" USING ("ContestId"))
GROUP BY "Score"."UserId";

alter table "CurrentContestScore"
  owner to postgres;

