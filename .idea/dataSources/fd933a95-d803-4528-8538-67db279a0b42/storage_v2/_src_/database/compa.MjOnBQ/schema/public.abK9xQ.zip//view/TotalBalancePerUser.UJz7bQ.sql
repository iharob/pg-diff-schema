create view "TotalBalancePerUser" as
SELECT sum("WalletTransaction"."Value") AS "Value",
       "WalletTransaction"."UserId"
FROM "WalletTransaction"
GROUP BY "WalletTransaction"."UserId";

alter table "TotalBalancePerUser"
  owner to postgres;

