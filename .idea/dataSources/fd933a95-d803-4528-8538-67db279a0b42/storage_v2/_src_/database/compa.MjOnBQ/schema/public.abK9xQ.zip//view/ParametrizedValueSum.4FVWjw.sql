create view "ParametrizedValueSum" as
SELECT sum(COALESCE("ParametrizedValue"."Value", 0))                                  AS "Value",
       COALESCE("ParametrizedValue"."TrackingDate", CURRENT_DATE)                     AS "TrackingDate",
       "ContestParticipant"."ParticipantId"                                           AS "UserId",
       COALESCE("ParametrizedValue"."Type", 'STEPS_WALKED'::"ParametrizedValueTypes") AS "Type",
       "ContestParticipant"."ContestId"
FROM ("ContestParticipant"
       LEFT JOIN "ParametrizedValue" ON ((("ParametrizedValue"."UserId" = "ContestParticipant"."ParticipantId") AND
                                          ("ParametrizedValue"."ContestId" = "ContestParticipant"."ContestId"))))
GROUP BY "ContestParticipant"."ParticipantId", "ParametrizedValue"."Type", "ParametrizedValue"."TrackingDate",
         "ContestParticipant"."ContestId";

alter table "ParametrizedValueSum"
  owner to postgres;

