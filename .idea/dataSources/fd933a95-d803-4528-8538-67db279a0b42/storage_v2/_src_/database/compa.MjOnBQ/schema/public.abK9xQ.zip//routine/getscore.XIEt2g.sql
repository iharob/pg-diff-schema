create function getscore(points bigint, pid integer) returns double precision
  immutable
  language plpgsql
as
$$
DECLARE
  result FLOAT;
BEGIN
  SELECT INTO result ROUND((points::FLOAT * "Representation"::FLOAT / "Max"::FLOAT)::NUMERIC, 1)
  FROM "Parameter"
  WHERE "Id" = pid;
  IF result IS NULL THEN
    RETURN 0;
  ELSE
    RETURN result;
  END IF;
END;
$$;

alter function getscore(bigint, integer) owner to postgres;

