create view "Score" as
SELECT "ParametrizedValueSum"."UserId",
       "Parameter"."Type",
       (floor(((("ParametrizedValueSum"."Value")::double precision * ("Parameter"."Representation")::double precision) /
               ("Parameter"."Max")::double precision)))::integer AS "Score",
       "ParametrizedValueSum"."TrackingDate",
       "ParametrizedValueSum"."ContestId"
FROM ((("ParametrizedValueSum"
  JOIN "Contest" ON (("Contest"."Id" = "ParametrizedValueSum"."ContestId")))
  JOIN "ContestParticipant" ON ((("ContestParticipant"."ContestId" = "ParametrizedValueSum"."ContestId") AND
                                 ("ContestParticipant"."ParticipantId" = "ParametrizedValueSum"."UserId"))))
       JOIN "Parameter" ON ((("Parameter"."ParameterSetId" = "Contest"."ParameterSetId") AND
                             ("Parameter"."Type" = "ParametrizedValueSum"."Type"))));

alter table "Score"
  owner to postgres;

